<?php
defined( 'ABSPATH' ) || exit;
require_once TK_PATH . 'inc/import.php';
require_once TK_PATH . 'inc/admin2.php';

add_action( 'admin_menu', 'tk_admin_menu' );
function tk_admin_menu() {
	add_menu_page( 'تسمه کارون', 'تسمه کارون', 'manage_options', 'tasmekarun', 'tk_page_folders', 'dashicons-groups', 56 );
	add_submenu_page( 'tasmekarun', 'پوشه‌های برند', 'پوشه‌های برند', 'manage_options', 'tasmekarun', 'tk_page_folders' );
	add_submenu_page( 'tasmekarun', 'پریست‌های ضریب', 'پریست‌های ضریب', 'manage_options', 'tk-presets', 'tk_page_presets' );
	add_submenu_page( 'tasmekarun', 'فرمول‌ها', 'فرمول‌ها', 'manage_options', 'tk-formulas', 'tk_page_formulas' );
	add_submenu_page( 'tasmekarun', 'موجودی و ایمپورت', 'موجودی و ایمپورت', 'manage_options', 'tk-stock', 'tk_page_stock' );
	add_submenu_page( 'tasmekarun', 'برندها', 'برندها', 'manage_options', 'tk-brands', 'tk_page_brands' );
	add_submenu_page( 'tasmekarun', 'دسته‌ها و بخش‌ها', 'دسته‌ها و بخش‌ها', 'manage_options', 'tk-sections', 'tk_page_sections' );
	add_submenu_page( 'tasmekarun', 'تنظیمات', 'تنظیمات', 'manage_options', 'tk-settings', 'tk_page_settings' );
}

function tk_ok() {
	return isset( $_POST['tk_nonce'] ) && wp_verify_nonce( $_POST['tk_nonce'], 'tk_act' ) && current_user_can( 'manage_options' );
}

function tk_style() { ?>
	<style>
	.tk-folders{display:flex;flex-wrap:wrap;gap:14px;margin-top:14px}
	.tk-folder{background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 18px;min-width:180px;text-align:center}
	.tk-folder .ico{font-size:38px;line-height:1.2}
	.tk-series{border:1px solid #e0e0e0;border-radius:6px;padding:10px 12px;margin:8px 0;background:#fff}
	.tk-series-body{margin-top:10px;border-top:1px dashed #ddd;padding-top:10px}
	.tk-row{margin:6px 0;display:flex;align-items:center;gap:8px;flex-wrap:wrap}
	.tk-sw{position:relative;display:inline-block;width:44px;height:22px;flex:0 0 auto}
	.tk-sw input{opacity:0;width:0;height:0;position:absolute}
	.tk-sw span{position:absolute;inset:0;background:#ccc;border-radius:22px;transition:.2s;cursor:pointer}
	.tk-sw span:before{content:"";position:absolute;width:16px;height:16px;border-radius:50%;background:#fff;top:3px;right:3px;transition:.2s}
	.tk-sw input:checked+span{background:#2271b1}
	.tk-sw input:checked+span:before{right:25px}
	</style>
	<?php
}

/* ================= پوشه‌های برند ================= */
function tk_page_folders() {
	global $wpdb; $p = $wpdb->prefix;

	if ( $_SERVER['REQUEST_METHOD'] === 'POST' && tk_ok() && isset( $_POST['tk_save_folder'] ) ) {
		$bid = (int) $_POST['brand_id'];
		$wpdb->update( "{$p}tk_brands", array( 'default_preset_id' => (int) $_POST['preset_id'] ), array( 'id' => $bid ) );
		$series = isset( $_POST['series'] ) ? (array) $_POST['series'] : array();
		$ids = array_map( 'intval', array_keys( $series ) );
		if ( $ids ) {
			$wpdb->query( "DELETE FROM {$p}tk_brand_series WHERE brand_id=$bid AND section_id NOT IN (" . implode( ',', $ids ) . ')' );
		} else {
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$p}tk_brand_series WHERE brand_id=%d", $bid ) );
		}
		foreach ( $series as $sid => $f ) {
			$wpdb->query( $wpdb->prepare(
				"INSERT INTO {$p}tk_brand_series (brand_id,section_id,coef_on,coef_value,formula_on,formula_key,image_id,desc_on,desc_text) VALUES (%d,%d,%d,%s,%d,%s,%d,%d,%s)
				 ON DUPLICATE KEY UPDATE coef_on=VALUES(coef_on), coef_value=VALUES(coef_value), formula_on=VALUES(formula_on), formula_key=VALUES(formula_key), image_id=VALUES(image_id), desc_on=VALUES(desc_on), desc_text=VALUES(desc_text)",
				$bid, (int) $sid,
				! empty( $f['coef_on'] ) ? 1 : 0,
				( isset( $f['coef_value'] ) && '' !== $f['coef_value'] ) ? floatval( $f['coef_value'] ) : null,
				! empty( $f['formula_on'] ) ? 1 : 0,
				! empty( $f['formula_key'] ) ? sanitize_text_field( $f['formula_key'] ) : null,
				isset( $f['image_id'] ) ? (int) $f['image_id'] : 0,
				! empty( $f['desc_on'] ) ? 1 : 0,
				isset( $f['desc_text'] ) ? wp_kses_post( $f['desc_text'] ) : null ) );
		}
		wp_redirect( add_query_arg( array( 'page' => 'tasmekarun', 'brand' => $bid, 'saved' => 1 ), admin_url( 'admin.php' ) ) ); exit;
	}

	$bid = isset( $_GET['brand'] ) ? (int) $_GET['brand'] : 0;
	tk_style();

	if ( ! $bid ) {
		$brands = $wpdb->get_results( "SELECT b.*, (SELECT COUNT(*) FROM {$p}tk_brand_series x WHERE x.brand_id=b.id) AS cnt FROM {$p}tk_brands b ORDER BY b.name_fa" );
		echo '<div class="wrap" dir="rtl"><h1>پوشه‌های برند</h1><div class="tk-folders">';
		foreach ( $brands as $b ) {
			echo '<div class="tk-folder"><div class="ico">📁</div><strong>' . esc_html( $b->name_fa ) . '</strong><br><small>' . (int) $b->cnt . ' سری فعال</small><br><a class="button" href="' . esc_url( add_query_arg( array( 'page' => 'tasmekarun', 'brand' => $b->id ), admin_url( 'admin.php' ) ) ) . '">باز کردن</a></div>';
		}
		echo '</div></div>';
		return;
	}

	$brand = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$p}tk_brands WHERE id=%d", $bid ) );
	if ( ! $brand ) { return; }
	wp_enqueue_media();
	$presets  = $wpdb->get_results( "SELECT * FROM {$p}tk_presets ORDER BY title_fa" );
	$formulas = $wpdb->get_results( "SELECT * FROM {$p}tk_formulas ORDER BY title_fa" );
	$cats     = $wpdb->get_results( "SELECT * FROM {$p}tk_categories ORDER BY sort" );
	$secs_all = $wpdb->get_results( "SELECT * FROM {$p}tk_sections ORDER BY slug" );
	$rows     = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$p}tk_brand_series WHERE brand_id=%d", $bid ) );
	$map = array();
	foreach ( $rows as $r ) { $map[ (int) $r->section_id ] = $r; }
	if ( isset( $_GET['saved'] ) ) { echo '<div class="notice notice-success"><p>پوشه ذخیره شد ✔</p></div>'; }
	?>
	<div class="wrap" dir="rtl">
	<h1>پوشه برند: <?php echo esc_html( $brand->name_fa ); ?> <a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=tasmekarun' ) ); ?>">بازگشت</a></h1>
	<form method="post">
		<?php wp_nonce_field( 'tk_act', 'tk_nonce' ); ?>
		<input type="hidden" name="brand_id" value="<?php echo $bid; ?>">
		<div class="tk-row" style="margin-bottom:14px">
			<strong>ضریب پیشفرض این برند:</strong>
			<select name="preset_id">
				<option value="0">— بدون پریست —</option>
				<?php foreach ( $presets as $pr ) : ?><option value="<?php echo $pr->id; ?>" <?php selected( (int) $brand->default_preset_id, (int) $pr->id ); ?>><?php echo esc_html( $pr->title_fa ); ?></option><?php endforeach; ?>
			</select>
			<small>(پریست‌ها از صفحه «پریست‌های ضریب» اضافه/حذف می‌شوند)</small>
		</div>
	<?php
	foreach ( $cats as $c ) {
		$secs = array();
		foreach ( $secs_all as $s ) { if ( (int) $s->category_id === (int) $c->id ) { $secs[] = $s; } }
		if ( ! $secs ) { continue; }
		$on_cnt = 0;
		foreach ( $secs as $s ) { if ( isset( $map[ (int) $s->id ] ) ) { $on_cnt++; } }
		echo '<h2 style="margin-top:22px">' . esc_html( $c->name_fa ) . ' <label style="font-weight:normal;margin-right:14px"><input type="checkbox" class="js-cat-on" data-cat="' . $c->id . '" ' . ( $on_cnt === count( $secs ) ? 'checked' : '' ) . '> کل این دسته</label></h2>';
		echo '<div id="tk-cat-' . $c->id . '">';
		foreach ( $secs as $s ) {
			$sid = (int) $s->id;
			$r = isset( $map[ $sid ] ) ? $map[ $sid ] : null;
			$on = null !== $r;
			?>
			<div class="tk-series">
				<label style="cursor:pointer"><input type="checkbox" class="js-series-on" name="series[<?php echo $sid; ?>][on]" value="1" <?php checked( $on ); ?>> <strong><?php echo esc_html( $s->slug ); ?></strong> — <?php echo esc_html( $s->name_fa ); ?></label>
				<div class="tk-series-body" style="<?php echo $on ? '' : 'display:none'; ?>">
					<div class="tk-row">
						<label class="tk-sw"><input type="checkbox" class="js-flip" data-target="tk-cv-<?php echo $sid; ?>" name="series[<?php echo $sid; ?>][coef_on]" value="1" <?php checked( $r && $r->coef_on ); ?>><span></span></label>
						ضریب دستی
						<span id="tk-cv-<?php echo $sid; ?>" style="<?php echo ( $r && $r->coef_on ) ? '' : 'display:none'; ?>">
							<input type="number" step="any" name="series[<?php echo $sid; ?>][coef_value]" value="<?php echo esc_attr( $r ? $r->coef_value : '' ); ?>" style="width:140px">
						</span>
						<small>(خاموش = ضریب از پریست پیشفرض برند)</small>
					</div>
					<div class="tk-row">
						<label class="tk-sw"><input type="checkbox" class="js-flip" data-target="tk-fk-<?php echo $sid; ?>" name="series[<?php echo $sid; ?>][formula_on]" value="1" <?php checked( $r && $r->formula_on ); ?>><span></span></label>
						فرمول اختصاصی
						<span id="tk-fk-<?php echo $sid; ?>" style="<?php echo ( $r && $r->formula_on ) ? '' : 'display:none'; ?>">
							<select name="series[<?php echo $sid; ?>][formula_key]">
								<?php foreach ( $formulas as $fo ) : ?><option value="<?php echo esc_attr( $fo->fkey ); ?>" <?php selected( $r ? $r->formula_key : '', $fo->fkey ); ?>><?php echo esc_html( $fo->title_fa . ' (' . $fo->fkey . ')' ); ?></option><?php endforeach; ?>
							</select>
						</span>
						<small>(خاموش = فرمول پیشفرض بخش)</small>
					</div>
					<div class="tk-row">
						عکس مشترک سری:
						<button type="button" class="button tk-up-btn" data-hid="tk-img-<?php echo $sid; ?>" data-img="tk-im-<?php echo $sid; ?>">انتخاب عکس</button>
						<input type="hidden" id="tk-img-<?php echo $sid; ?>" name="series[<?php echo $sid; ?>][image_id]" value="<?php echo esc_attr( $r ? $r->image_id : 0 ); ?>">
						<img id="tk-im-<?php echo $sid; ?>" src="<?php echo esc_url( $r && $r->image_id ? ( wp_get_attachment_image_url( (int) $r->image_id, 'thumbnail' ) ) : '' ); ?>" style="<?php echo ( $r && $r->image_id ) ? '' : 'display:none'; ?>max-height:40px;border-radius:4px">
					</div>
					<div class="tk-row">
						<label class="tk-sw"><input type="checkbox" class="js-flip" data-target="tk-dt-<?php echo $sid; ?>" name="series[<?php echo $sid; ?>][desc_on]" value="1" <?php checked( $r && $r->desc_on ); ?>><span></span></label>
						دسکریپشن دستی
						<span id="tk-dt-<?php echo $sid; ?>" style="<?php echo ( $r && $r->desc_on ) ? '' : 'display:none'; ?>;width:100%">
							<textarea name="series[<?php echo $sid; ?>][desc_text]" rows="3" style="width:100%"><?php echo esc_textarea( $r ? $r->desc_text : '' ); ?></textarea>
						</span>
						<small>(خاموش = دسکریپشن اتوماتیک با مشخصات فنی داینامیک)</small>
					</div>
				</div>
			</div>
			<?php
		}
		echo '</div>';
	}
	?>
		<p><button name="tk_save_folder" value="1" class="button button-primary">ذخیره پوشه</button></p>
	</form>
	<script>
	document.addEventListener('change', function(e){
		var t = e.target;
		if ( t.classList.contains('js-cat-on') ) {
			var box = document.getElementById('tk-cat-' + t.dataset.cat);
			box.querySelectorAll('.js-series-on').forEach(function(s){ s.checked = t.checked; s.dispatchEvent(new Event('change')); });
		} else if ( t.classList.contains('js-series-on') ) {
			t.closest('.tk-series').querySelector('.tk-series-body').style.display = t.checked ? 'block' : 'none';
		} else if ( t.classList.contains('js-flip') ) {
			var el = document.getElementById(t.dataset.target);
			if ( el ) el.style.display = t.checked ? '' : 'none';
		}
	});
	document.addEventListener('click', function(e){
		var b = e.target.closest('.tk-up-btn');
		if ( ! b ) return;
		e.preventDefault();
		var hid = document.getElementById(b.dataset.hid), img = document.getElementById(b.dataset.img);
		var m = wp.media({ multiple: false });
		m.on('select', function(){
			var a = m.state().get('selection').first().toJSON();
			hid.value = a.id; img.src = a.url; img.style.display = 'inline-block';
		});
		m.open();
	});
	</script>
	</div>
	<?php
}

/* ================= پریست‌های ضریب ================= */
function tk_page_presets() {
	global $wpdb; $p = $wpdb->prefix;

	if ( $_SERVER['REQUEST_METHOD'] === 'POST' && tk_ok() ) {
		if ( isset( $_POST['tk_add_preset'] ) ) {
			$wpdb->query( $wpdb->prepare( "INSERT INTO {$p}tk_presets (title_fa) VALUES (%s)", sanitize_text_field( $_POST['title_fa'] ) ) );
		} elseif ( isset( $_POST['tk_del_preset'] ) ) {
			$id = (int) $_POST['preset_id'];
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$p}tk_presets WHERE id=%d", $id ) );
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$p}tk_preset_coefs WHERE preset_id=%d", $id ) );
			$wpdb->query( $wpdb->prepare( "UPDATE {$p}tk_brands SET default_preset_id=0 WHERE default_preset_id=%d", $id ) );
		} elseif ( isset( $_POST['tk_save_preset_coefs'] ) ) {
			$id = (int) $_POST['preset_id'];
			foreach ( (array) $_POST['pcoef'] as $sid => $v ) {
				$sid = (int) $sid;
				if ( '' === trim( (string) $v ) ) {
					$wpdb->query( $wpdb->prepare( "DELETE FROM {$p}tk_preset_coefs WHERE preset_id=%d AND section_id=%d", $id, $sid ) );
				} else {
					$wpdb->query( $wpdb->prepare( "INSERT INTO {$p}tk_preset_coefs (preset_id,section_id,coef) VALUES (%d,%d,%f) ON DUPLICATE KEY UPDATE coef=VALUES(coef)", $id, $sid, floatval( $v ) ) );
				}
			}
		}
		wp_redirect( add_query_arg( array( 'page' => 'tk-presets' ), admin_url( 'admin.php' ) ) . ( isset( $_POST['edit'] ) ? '&edit=' . (int) $_POST['edit'] : '' ) ); exit;
	}

	tk_style();
	$edit = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : 0;
	echo '<div class="wrap" dir="rtl"><h1>پریست‌های ضریب پیشفرض</h1>';

	if ( $edit ) {
		$pr = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$p}tk_presets WHERE id=%d", $edit ) );
		if ( $pr ) {
			$coefs = $wpdb->get_results( $wpdb->prepare( "SELECT section_id, coef FROM {$p}tk_preset_coefs WHERE preset_id=%d", $edit ) );
			$cmap = array();
			foreach ( $coefs as $c ) { $cmap[ (int) $c->section_id ] = $c->coef; }
			$secs = $wpdb->get_results( "SELECT s.*, c.name_fa AS cname FROM {$p}tk_sections s JOIN {$p}tk_categories c ON c.id=s.category_id ORDER BY c.sort, s.slug" );
			echo '<h2>ضریب‌های پریست: ' . esc_html( $pr->title_fa ) . '</h2><form method="post">' . wp_nonce_field( 'tk_act', 'tk_nonce', true ) . '<input type="hidden" name="preset_id" value="' . $edit . '"><input type="hidden" name="edit" value="' . $edit . '">';
			echo '<table class="widefat striped" style="max-width:700px"><tr><th>بخش</th><th>ضریب (خالی = حذف)</th></tr>';
			foreach ( $secs as $s ) {
				echo '<tr><td>' . esc_html( $s->cname . ' / ' . $s->slug ) . '</td><td><input type="number" step="any" name="pcoef[' . $s->id . ']" value="' . esc_attr( isset( $cmap[ (int) $s->id ] ) ? $cmap[ (int) $s->id ] : '' ) . '" style="width:150px"></td></tr>';
			}
			echo '</table><p><button name="tk_save_preset_coefs" value="1" class="button button-primary">ذخیره ضریب‌ها</button></p></form>';
		}
	} else {
		$presets = $wpdb->get_results( "SELECT pr.*, (SELECT COUNT(*) FROM {$p}tk_preset_coefs pc WHERE pc.preset_id=pr.id) AS cc, (SELECT COUNT(*) FROM {$p}tk_brands b WHERE b.default_preset_id=pr.id) AS bc FROM {$p}tk_presets pr ORDER BY pr.title_fa" );
		echo '<table class="widefat striped" style="max-width:800px"><tr><th>نام پریست</th><th>تعداد ضریب</th><th>برندهای استفاده‌کننده</th><th>عملیات</th></tr>';
		foreach ( $presets as $pr ) {
			echo '<tr><td>' . esc_html( $pr->title_fa ) . '</td><td>' . (int) $pr->cc . '</td><td>' . (int) $pr->bc . '</td><td>
			<a class="button button-small" href="' . esc_url( add_query_arg( array( 'page' => 'tk-presets', 'edit' => $pr->id ), admin_url( 'admin.php' ) ) ) . '">ویرایش ضریب‌ها</a>
			<form method="post" style="display:inline" onsubmit="return confirm(\'پریست حذف شود؟\');">' . wp_nonce_field( 'tk_act', 'tk_nonce', true ) . '<input type="hidden" name="preset_id" value="' . $pr->id . '"><button name="tk_del_preset" value="1" class="button button-small">حذف</button></form>
			</td></tr>';
		}
		echo '</table>';
		echo '<h2>افزودن پریست جدید</h2><form method="post">' . wp_nonce_field( 'tk_act', 'tk_nonce', true ) . '<input type="text" name="title_fa" placeholder="مثلاً چینی درجه ۲" required> <button name="tk_add_preset" value="1" class="button button-primary">افزودن</button></form>';
	}
	echo '</div>';
}

/* ================= فرمول‌ها ================= */
function tk_page_formulas() {
	global $wpdb; $p = $wpdb->prefix;
	$err = '';

	if ( $_SERVER['REQUEST_METHOD'] === 'POST' && tk_ok() ) {
		if ( isset( $_POST['tk_save_formula'] ) ) {
			$fkey = sanitize_text_field( $_POST['fkey'] );
			$expr = sanitize_text_field( $_POST['expr'] );
			$test = TK_Engine::eval_expr( $expr, array( 'LENGTH' => 100, 'RIBS' => 8, 'COEF' => 1000 ) );
			if ( '' === $fkey || null === $test ) {
				$err = 'عبارت نامعتبر است. فقط عدد، پرانتز، عملگرهای + - * / و توکن‌های LENGTH و RIBS و COEF مجازند.';
			} else {
				$wpdb->query( $wpdb->prepare( "INSERT INTO {$p}tk_formulas (fkey,title_fa,expr) VALUES (%s,%s,%s) ON DUPLICATE KEY UPDATE title_fa=VALUES(title_fa), expr=VALUES(expr)", $fkey, sanitize_text_field( $_POST['title_fa'] ), $expr ) );
			}
		} elseif ( isset( $_POST['tk_del_formula'] ) ) {
			$fkey = sanitize_text_field( $_POST['fkey'] );
			$used = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}tk_sections WHERE formula_key=%s", $fkey ) )
			      + (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$p}tk_brand_series WHERE formula_key=%s", $fkey ) );
			if ( $used ) {
				$err = 'این فرمول در ' . $used . ' جا استفاده شده؛ اول استفاده‌ها را عوض کنید.';
			} else {
				$wpdb->query( $wpdb->prepare( "DELETE FROM {$p}tk_formulas WHERE fkey=%s", $fkey ) );
			}
		}
	}

	tk_style();
	$formulas = $wpdb->get_results( "SELECT * FROM {$p}tk_formulas ORDER BY title_fa" );
	echo '<div class="wrap" dir="rtl"><h1>فرمول‌های محاسبه قیمت</h1>';
	if ( $err ) { echo '<div class="notice notice-error"><p>' . esc_html( $err ) . '</p></div>'; }
	echo '<table class="widefat striped" style="max-width:900px"><tr><th>کد</th><th>نام</th><th>عبارت محاسبه</th><th>تست (B70 با ضریب ۱۰۰۰۰)</th><th>عملیات</th></tr>';
	foreach ( $formulas as $f ) {
		$tv = TK_Engine::eval_expr( $f->expr, array( 'LENGTH' => 70, 'RIBS' => 1, 'COEF' => 100000 ) );
		echo '<tr><td><code>' . esc_html( $f->fkey ) . '</code></td><td>' . esc_html( $f->title_fa ) . '</td><td dir="ltr"><code>' . esc_html( $f->expr ) . '</code></td><td>' . ( null === $tv ? '—' : esc_html( number_format_i18n( $tv ) ) ) . '</td>
		<td><form method="post" style="display:inline">' . wp_nonce_field( 'tk_act', 'tk_nonce', true ) . '<input type="hidden" name="fkey" value="' . esc_attr( $f->fkey ) . '"><button name="tk_del_formula" value="1" class="button button-small" onclick="return confirm(\'فرمول حذف شود؟\');">حذف</button></form></td></tr>';
	}
	echo '</table>';
	echo '<h2>افزودن / ویرایش فرمول</h2>
	<form method="post">' . wp_nonce_field( 'tk_act', 'tk_nonce', true ) . '
	<p>کد فرمول (انگلیسی): <input type="text" name="fkey" dir="ltr" required placeholder="STD"> &nbsp; نام: <input type="text" name="title_fa" required placeholder="طول در ضریب"></p>
	<p>عبارت محاسبه: <input type="text" name="expr" dir="ltr" style="width:340px" required placeholder="LENGTH * COEF">
	&nbsp; درج توکن: <button type="button" class="button button-small" onclick="tkIns(\'LENGTH *\')">LENGTH</button> <button type="button" class="button button-small" onclick="tkIns(\'RIBS *\')">RIBS</button> <button type="button" class="button button-small" onclick="tkIns(\'COEF\')">COEF</button></p>
	<p class="description">LENGTH = طول تسمه · RIBS = تعداد شیار · COEF = ضریب. عملگرهای مجاز: + - * / و پرانتز. مثال شیاری: <code dir="ltr">RIBS * LENGTH * COEF</code></p>
	<p><button name="tk_save_formula" value="1" class="button button-primary">ثبت فرمول</button></p></form>
	<script>function tkIns(t){var i=document.querySelector(\'input[name=expr]\');i.value=(i.value+i.value&&!i.value.endsWith(\' \')&&!i.value.endsWith(\'*\')&&!i.value.endsWith(\'(\')?i.value:i.value)+t;i.focus();}</script>
	</div>';
}